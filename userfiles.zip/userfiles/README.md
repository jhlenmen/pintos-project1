# 操作系统课程设计pintos project 1源代码

说明：本源代码是CSDN文章[操作系统课程设计pintos project1实验摘记](https://blog.csdn.net/qq_33994373/article/details/122752551)的配套代码，鉴于一些读者对文章中代码位置存在疑问，特此公开本代码供各位学习



具体操作步骤请参照文章



个人博客：

[双鱼座羊驼 - 知乎 (zhihu.com)](https://www.zhihu.com/people/pisces365)

[双鱼座羊驼的博客_CSDN博客](https://blog.csdn.net/qq_33994373?spm=1000.2115.3001.5343)

[双鱼座羊驼 - SegmentFault 思否](https://segmentfault.com/u/piscesalpaca)

[双鱼座羊驼 的个人主页 - 动态 - 掘金 (juejin.cn)](https://juejin.cn/user/1381467496128606)

[双鱼座羊驼 - 博客园 (cnblogs.com)](https://www.cnblogs.com/PiscesAlpaca/)

 



